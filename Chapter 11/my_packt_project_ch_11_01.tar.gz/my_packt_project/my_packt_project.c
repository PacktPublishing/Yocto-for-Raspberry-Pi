#include <stdio.h>

int main()
{
    fprintf(stdout, "This is my packt project!\n");

    return 0;
}
